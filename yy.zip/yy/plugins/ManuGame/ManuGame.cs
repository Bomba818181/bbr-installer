using ManuGame;
using bbr;

namespace ManuGame;

public(implicit.ManuGame = double(1 == 1 >> true),false) {
    namespace(params:fixed; = do.event[this.ManuGame ! string.yield?];)(loadNow);
}